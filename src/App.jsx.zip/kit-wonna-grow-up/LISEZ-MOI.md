# Wonna Grow Up — kit de mise en ligne depuis un iPhone

Tout se fait dans Safari. Aucun terminal, aucune installation.
Cloudflare compile le projet sur ses serveurs.

## 1. Créer le dépôt

- Va sur github.com, connecte-toi (compte gratuit).
- Bouton **+** en haut à droite → **New repository**.
- Nom : `wonna-grow-up`. Laisse en **Private** si tu veux. **Create repository**.

## 2. Déposer les fichiers

Sur la page du dépôt vide : **uploading an existing file**.

Dépose tous les fichiers de ce kit **en respectant les dossiers** :

    package.json
    vite.config.js
    tailwind.config.js
    postcss.config.js
    index.html
    src/main.jsx
    src/index.css
    src/App.jsx        <-- TON FICHIER, renommé exactement App.jsx
    public/manifest.json
    public/sw.js
    public/icones/icone-192.png
    public/icones/icone-512.png
    public/icones/apple-touch-icon.png
    public/icones/badge-96.png

Astuce iPhone : l'interface GitHub accepte le glisser-déposer depuis
l'app Fichiers, y compris des dossiers entiers. Sinon, dépose les
fichiers racine d'abord, puis recommence en tapant `src/` ou
`public/icones/` devant le nom du fichier pour créer les dossiers.

**Le plus important : ton fichier JSX doit s'appeler `App.jsx` et être
dans le dossier `src/`.** Il remplace le fichier placeholder fourni.

## 3. Brancher Cloudflare

- Va sur dash.cloudflare.com, crée un compte gratuit.
- **Workers & Pages** → **Create application** → onglet **Pages**
  → **Connect to Git**.
- Autorise GitHub, choisis le dépôt `wonna-grow-up`.
- Réglages de build :

      Framework preset          Vite
      Build command             npm run build
      Build output directory    dist

- **Save and Deploy**. Compte deux à trois minutes.

Tu obtiens une adresse du type `wonna-grow-up.pages.dev`, en HTTPS.

## 4. Sur l'écran d'accueil

- Ouvre l'adresse **dans Safari** (pas Chrome).
- Bouton **Partager** → **Sur l'écran d'accueil**.
- L'app s'ouvre en plein écran, avec son icône.

Les notifications de fin de repos ne fonctionnent qu'à partir de là :
iOS ne les autorise pas depuis un onglet Safari. Va dans
Profil → iPhone → Autoriser les notifications, puis Envoyer un test.

## 5. Connecter le coach (optionnel)

Sans clé API, tout fonctionne sauf le chat du coach : programme,
séances, journal, fiches, 3D, graphiques, sauvegarde.

Pour activer le coach, le plus sûr est un proxy Cloudflare Worker qui
garde la clé côté serveur. Renseigne ensuite son adresse dans
Profil → iPhone → Proxy.

Évite de coller ta clé API directement dans l'app si le site est
public : elle repartirait dans chaque requête depuis le navigateur et
serait lisible par n'importe qui.

## En cas d'échec du build

Cloudflare affiche le journal complet. Les deux causes les plus
fréquentes :

- `Could not resolve "./App.jsx"` → ton fichier n'est pas dans `src/`
  ou n'est pas nommé exactement `App.jsx`.
- Une dépendance manquante → vérifie que `package.json` a bien été
  déposé à la racine, pas dans un sous-dossier.
